# data preprocessing
library(tidyverse)
library(lubridate)
# data exploration
library(summarytools) # for user-friendly html summaries of data
library(ggmap) # for plotting data on a map
# for meta-ml
library(tidymodels)
library(dplyr)

options(dplyr.width = Inf) # show all columns when printing to console
theme_set(theme_minimal()) # set ggplot theme for cleaner plotting

### Import physicians and clean up
physicians <- read_csv('physicians.csv')
physicians <- physicians %>% rename(Physician_State = State) %>% rename(Physician_Country = Country)

physicians <- physicians %>% select(-First_Name,-Middle_Name,-Last_Name,-Physician_Country,-Name_Suffix, -Province)

#countedLicenseState1 <- physicians %>% 
# group_by(License_State_1) %>% 
#  summarise(count=n())
#countedLicenseState1

companies <- read_csv('companies.csv')
companies <- companies %>% rename(Company_State = State) %>% rename(Company_Country = Country)


## Transactions
payments <- read_csv('payments.csv')

payments <- payments %>% select(-Product_Name_1, -Product_Name_2, -Product_Name_3,-Product_Category_1,
                                -Product_Category_2, -Product_Category_3, -Product_Type_2, -Product_Type_3, 
                                -Product_Type_1, -Product_Code_1, -Product_Code_2, -Product_Code_3, -Contextual_Information)


# change ownership interest to bool
payments <- payments %>% mutate(Ownership_Indicator = ifelse(Ownership_Indicator == "Yes", 1,0))
sapply(payments, class)
transform(payments, Ownership_Indicator = as.logical(Ownership_Indicator))

# Transform date to type Date
payments <- transform(payments, Date = as_date(payments$Date, format = "%d/%m/%Y"))
head(payments) %>% dfSummary %>% view('browser')

# Transform third party recipient to factor
thirdparty <- payments %>% 
  group_by(Third_Party_Recipient) %>% 
  summarise(count=n())
thirdparty
payments$Third_Party_Recipient <- as.factor(payments$Third_Party_Recipient)


# Transform nature of payment to factor
naturOFPayment <- payments %>% 
  group_by(Nature_of_Payment_or_Transfer_of_Value) %>% 
  summarise(count=n())
naturOFPayment

payments$Nature_of_Payment_or_Transfer_of_Value <- as.factor(payments$Nature_of_Payment_or_Transfer_of_Value)

#Transform FORM of payments
#formOfPayment <- payments %>% 
#  group_by(Form_of_Payment_or_Transfer_of_Value) %>% 
#  summarise(count=n())
#formOfPayment

payments$Form_of_Payment_or_Transfer_of_Value <- as.factor(payments$Form_of_Payment_or_Transfer_of_Value)

# Selecting test set physicians only
testSetPhysicians <- physicians %>% filter(set == "test")

# Check if test set matches the submission template
submission_template <- read_csv('submission_template.csv')
template_ids <- submission_template %>% arrange(id) %>% pull(id)
test_ids <- testSetPhysicians %>% arrange(id) %>% pull(id)
if(!all(template_ids == test_ids)) warning("Testset does not match template!")

# Join together all original tables
complete_set <- inner_join(payments, physicians, by = c("Physician_ID" = "id"))
complete_set <- inner_join(complete_set, companies, by = c("Company_ID" = "Company_ID"))
#complete_set %>% dfSummary %>% view('browser')


#check if company state might influence how many transactions with OI are recorded
distribution <- complete_set %>% group_by(Company_State) %>% summarise(ratio = sum(Ownership_Indicator == 1)/n())

# Create solution vector
complete_set <- complete_set %>% group_by(Physician_ID) %>% 
  mutate(P_has_OwnInt=if(any(Ownership_Indicator == TRUE)) {TRUE} else {FALSE})

# Count total transactions
complete_set <- complete_set %>% group_by(Physician_ID) %>% mutate(total_transactions = n()) %>% ungroup()

# Construct test and training set
test <- semi_join(complete_set, testSetPhysicians, by = c("Physician_ID" = "id")) %>% select(-set)
train <- anti_join(complete_set, test, by = c("Physician_ID" = "Physician_ID")) %>% select(-set)
 
#test %>% dfSummary %>% view('browser')
#train %>% dfSummary %>% view('browser')

# Only select total TX for ownership indicator TRUE or FALSE
## first select only transactions that have NO ownership indicator to simulate test set
tmp <- train %>% group_by(Physician_ID) %>% filter(Ownership_Indicator == 0) %>%select(P_has_OwnInt, total_transactions) %>% unique

tmp_only_FALSE <- train %>% select(P_has_OwnInt, total_transactions) %>% filter(P_has_OwnInt == FALSE) %>% select(total_transactions) %>% unique()
tmp_only_TRUE <- train %>% select(P_has_OwnInt, total_transactions) %>% filter(P_has_OwnInt == TRUE) %>% select(total_transactions) %>% unique()

# View the boxplots
tmp %>% ggplot(aes(y=total_transactions, x=P_has_OwnInt, fill = P_has_OwnInt)) +
  geom_boxplot()+
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# barplots showing the distribution of number for transactions for both subsets
barplot(table(cut(tmp_only_FALSE$total_transactions, seq(0, 3000, 200)))/nrow(tmp_only_FALSE))
barplot(table(cut(tmp_only_TRUE$total_transactions, seq(0, 3000, 200)))/nrow(tmp_only_TRUE))

# Get precise data
#summary(tmp_only_FALSE)
#summary(tmp_only_TRUE)

# We see that the total number of transactions is generally higher for Physicians that
# have an Ownership Interest
# If a physician has received more than 825 transactions (3rd Quartile of tmp_only_FALSE), it seems likelier that the physician
# has an ownership interest in a company.
# We therefore set this value as a cutoff for a binominal variable 'High_Amount_of_TX', which is TRUE for values above the cutoff
nr_TX_cutoff_3qt_FALSE <- quantile(tmp_only_FALSE$total_transactions, 0.75)
nr_TX_cutoff_3qt_TRUE <- quantile(tmp_only_TRUE$total_transactions, 0.75)

complete_set <- complete_set %>% mutate(total_transactions = cut(total_transactions, breaks = c(0, nr_TX_cutoff_3qt_FALSE, nr_TX_cutoff_3qt_TRUE, Inf)))


#Difference in Nature of Payment when comparing subsets P_has_OwnInt = TRUE/FALSE

allOwnInd <- complete_set %>% filter(Ownership_Indicator == 0)
allOwnInd <- allOwnInd %>% select(Nature_of_Payment_or_Transfer_of_Value) %>% group_by(Nature_of_Payment_or_Transfer_of_Value) %>% mutate(count = n()) %>% unique()
allOwnInd <- allOwnInd %>% mutate(relFreq = count/sum(allOwnInd$count))

onlyTRUEOwnInd <- complete_set %>% filter(P_has_OwnInt == TRUE) %>% filter(Ownership_Indicator == 0)

onlyTRUEOwnInd <- onlyTRUEOwnInd %>% select(Nature_of_Payment_or_Transfer_of_Value) %>% group_by(Nature_of_Payment_or_Transfer_of_Value) %>% mutate(count = n()) %>% unique()
onlyTRUEOwnInd <- onlyTRUEOwnInd %>% mutate(relFreq = count/sum(onlyTRUEOwnInd$count))

onlyFALSEOwnInd <- complete_set %>% filter(P_has_OwnInt == FALSE)

onlyFALSEOwnInd <- onlyFALSEOwnInd %>% select(Nature_of_Payment_or_Transfer_of_Value) %>% group_by(Nature_of_Payment_or_Transfer_of_Value) %>% mutate(count = n()) %>% unique()
onlyFALSEOwnInd <- onlyFALSEOwnInd %>% mutate(relFreq = count/sum(onlyFALSEOwnInd$count))

#### MICHAEL START #####


### Check for each physician, if rel frequency of nature of payment is higher/lower than average
# check for Travel and Lodging
complete_set <- complete_set %>% group_by(Physician_ID) %>%
  mutate(high_Travel_Lodg = sum(Nature_of_Payment_or_Transfer_of_Value == "Travel and Lodging")/n() >= allOwnInd$relFreq[allOwnInd$Nature_of_Payment_or_Transfer_of_Value == "Travel and Lodging"])

# check for Food and Beverage
complete_set <- complete_set %>% group_by(Physician_ID) %>%
  mutate(high_Food_Bev = sum(Nature_of_Payment_or_Transfer_of_Value == "Food and Beverage")/n() >= allOwnInd$relFreq[allOwnInd$Nature_of_Payment_or_Transfer_of_Value == "Food and Beverage"])

# check for 

plot(allOwnInd$Nature_of_Payment_or_Transfer_of_Value, allOwnInd$relFreq, ylim = c(0,1))
plot(onlyTRUEOwnInd$Nature_of_Payment_or_Transfer_of_Value, onlyTRUEOwnInd$relFreq, ylim = c(0,1))
plot(onlyFALSEOwnInd$Nature_of_Payment_or_Transfer_of_Value, onlyFALSEOwnInd$relFreq, ylim = c(0,1))

### MICHAEL END



###TIANRAN STARTED###########


#Count number of Licenses for each physician ID
physicians <- physicians %>% 
  mutate(License_State_1n = ifelse(is.na(License_State_1),0,1)) %>%
  mutate(License_State_2n = ifelse(is.na(License_State_2),0,1)) %>% 
  mutate(License_State_3n = ifelse(is.na(License_State_3),0,1)) %>% 
  mutate(License_State_4n = ifelse(is.na(License_State_4),0,1)) %>% 
  mutate(License_State_5n = ifelse(is.na(License_State_5),0,1))

physicians <- physicians %>% group_by(id) %>% mutate(Sum_of_Licenses = sum(License_State_1n,License_State_2n,License_State_3n,License_State_4n,License_State_5n))

## first select only Sum_of_Licenses that have NO ownership indicator to simulate test set
tl <- train %>% group_by(Physician_ID) %>% filter(Ownership_Indicator == 0) %>%select(P_has_OwnInt, Sum_of_Licenses) %>% unique()

## when OI is true, count the number of physicians for each number of licenses
train_selected_by_licenseTRUE <- train %>% select(Physician_ID,P_has_OwnInt,Sum_of_Licenses) %>% filter(P_has_OwnInt == TRUE)
train_selected_by_licenseTRUE <- aggregate(.~Physician_ID, data = train_selected_by_licenseTRUE, FUN = mean) 
train_selected_by_licenseTRUE <- train_selected_by_licenseTRUE %>% 
  select(Physician_ID,Sum_of_Licenses) %>% 
  group_by(Sum_of_Licenses) %>% 
  summarise(count = n())

### find the ratio of each number of licenses
train_selected_by_licenseTRUE <- train_selected_by_licenseTRUE %>% mutate(Freq = count/sum(train_selected_by_licenseFALSE$count))

## when OI is false, count the number of physicians for each number of licenses
train_selected_by_licenseFALSE <- train %>% select(Physician_ID,P_has_OwnInt,Sum_of_Licenses) %>% filter(P_has_OwnInt == FALSE)
train_selected_by_licenseFALSE <- aggregate(.~Physician_ID, data = train_selected_by_licenseFALSE, FUN = mean) 
train_selected_by_licenseFALSE <- train_selected_by_licenseFALSE %>% 
  select(Physician_ID,Sum_of_Licenses) %>% 
  group_by(Sum_of_Licenses) %>% 
  summarise(count = n())

### find the ratio of each number of licenses
train_selected_by_licenseFALSE <- train_selected_by_licenseFALSE %>% mutate(Freq = count/sum(train_selected_by_licenseFALSE$count))

#compare the ratio between OI is TRUE & FALSE
train_selected_by_licenseTRUE %>% ggplot(aes(y= Freq, x=Sum_of_Licenses, fill = Phy_count)) +
  geom_bar(stat = 'identity') + ylim(0,0.7)

train_selected_by_licenseFALSE %>% ggplot(aes(y= Freq, x=Sum_of_Licenses, fill = Phy_count)) +
  geom_bar(stat = 'identity') + ylim(0,0.7)